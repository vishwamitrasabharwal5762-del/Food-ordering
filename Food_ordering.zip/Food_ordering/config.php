<?php
	
	//default database configuration
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "fosdb";

?>